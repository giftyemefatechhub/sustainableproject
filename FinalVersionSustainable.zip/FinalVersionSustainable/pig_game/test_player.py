import unittest
from unittest.mock import patch
from dice import Dice
from highscore import Highscore
from player import Player


class PlayerTestCase(unittest.TestCase):
    """Test case for the Player class."""

    def setUp(self):
        """Set up the test case."""
        self.player = Player("Player")

    def tearDown(self):
        """Tear down the test case."""
        self.player = None

    def test_str(self):
        """Test the __str__ method."""
        expected_output = "Player"
        self.assertEqual(str(self.player), expected_output)

    @patch("builtins.input", side_effect=["r", "h"])
    def test_round(self, mock_input):
        """Test the round method."""
        # Add assertions here to check the output and behavior of the round method
        # Make sure to mock the input function to simulate user input

    @patch("builtins.input", side_effect=["y", "New Name"])
    def test_rename(self, mock_input):
        """Test the rename method."""
        # Add assertions here to check the output and behavior of the rename method
        # Make sure to mock the input function to simulate user input


if __name__ == "__main__":
    unittest.main()
