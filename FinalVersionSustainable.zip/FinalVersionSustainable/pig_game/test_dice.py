import unittest
from random import seed
from random import randint
from dice import Dice


class TestDice(unittest.TestCase):
    """Test cases for the Dice class."""

    def setUp(self):
        """Set up the test case with a fixed seed for random number generation."""
        seed(123)

    def test_dice_value(self):
        """Test the value of the dice."""
        # Create an instance of the Dice class
        dice = Dice()

        # Set the expected value based on the fixed seed
        expected_value = 1

        # Assert that the actual value matches the expected value
        self.assertEqual(dice.value, expected_value)


if __name__ == '__main__':
    unittest.main()
