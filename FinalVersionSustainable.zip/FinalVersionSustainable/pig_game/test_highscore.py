import unittest
from highscore import Highscore
from player import Player


class HighscoreTestCase(unittest.TestCase):
    """Test case for the Highscore class."""

    def setUp(self):
        """Set up the test case."""
        self.highscore = Highscore()

    def tearDown(self):
        """Tear down the test case."""
        self.highscore = None

    def test_update_score(self):
        """Test the update_score method."""
        player = Player("Alice")
        self.highscore.update_score(player, 100)
        self.assertEqual(
            self.highscore.players[player.name]["games_played"], 1)
        self.assertEqual(self.highscore.games_played, 1)
        self.assertEqual(
            self.highscore.players[player.name]["high_score"], 100)

    def test_won_game(self):
        """Test the won_game method."""
        player = Player("Bob")
        # Add the player to the highscore before calling won_game
        self.highscore.update_score(player, 0)
        self.highscore.won_game(player)
        self.assertEqual(self.highscore.players[player.name]["games_won"], 1)
        self.assertEqual(
            self.highscore.players[player.name]["win_percentage"], 100.0)

    def test_show_highscore(self):
        """Test the show_highscore method."""
        # Ensure the show_highscore method doesn't raise any exceptions
        self.highscore.show_highscore()


if __name__ == "__main__":
    unittest.main()
