import unittest
from game import Game


class GameTestCase(unittest.TestCase):
    """Test case for the Game class."""

    def setUp(self):
        """Set up the test case."""
        self.game = Game()

    def tearDown(self):
        """Tear down the test case."""
        self.game = None

    def test_rules(self):
        """Test the rules method."""
        # Ensure the rules method doesn't raise any exceptions
        self.game.rules()

    def test_restart(self):
        """Test the restart method."""
        # Ensure the restart method doesn't raise any exceptions
        self.game.restart()

    def test_play(self):
        """Test the play method."""
        # Ensure the play method doesn't raise any exceptions
        self.game.play()


if __name__ == "__main__":
    unittest.main()