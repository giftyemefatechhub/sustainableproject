import unittest
from dice import Dice
from intelligent import Intelligent


class IntelligentTestCase(unittest.TestCase):
    """Test case for the Intelligent class."""

    def setUp(self):
        """Set up the test case."""
        self.intelligent = Intelligent("Computer Player")

    def tearDown(self):
        """Tear down the test case."""
        self.intelligent = None

    def test_round(self):
        """Test the round method."""
        # Test for difficulty level 1
        self.intelligent.difficulty_level = 1
        self.intelligent.round_score = 0
        self.intelligent.computer_score = 0
        self.intelligent.round()
        # Add assertions here to check if the expected conditions are met

        # Test for difficulty level 2
        self.intelligent.difficulty_level = 2
        self.intelligent.round_score = 0
        self.intelligent.computer_score = 0
        self.intelligent.round()
        # Add assertions here to check if the expected conditions are met

        # Test for difficulty level 3
        self.intelligent.difficulty_level = 3
        self.intelligent.round_score = 0
        self.intelligent.computer_score = 0
        self.intelligent.round()
        # Add assertions here to check if the expected conditions are met

    def test_str(self):
        """Test the __str__ method."""
        expected_output = "Computer Player"
        self.assertEqual(str(self.intelligent), expected_output)


if __name__ == "__main__":
    unittest.main()
